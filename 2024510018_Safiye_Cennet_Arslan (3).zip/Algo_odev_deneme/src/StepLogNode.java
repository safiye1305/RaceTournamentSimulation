public class StepLogNode {
    String car1Line;
    String car2Line;
    int stepNumber;
    StepLogNode next;

    public StepLogNode(int stepNumber, String car1Line, String car2Line) {
        this.stepNumber = stepNumber;
        this.car1Line = car1Line;
        this.car2Line = car2Line;
        this.next = null;
    }
}