public class StepLogSLL {
    StepLogNode head;
    StepLogNode tail;

    public StepLogSLL() {
        head = null;
        tail = null;
    }

    public void add(int stepNumber, String car1Line, String car2Line) {
        StepLogNode node = new StepLogNode(stepNumber, car1Line, car2Line);
        if (head == null) {
            head = node;
            tail = node;
        } else {
            tail.next = node;
            tail = node;
        }
    }

    public int count() {
        int c = 0;
        StepLogNode cur = head;
        while (cur != null) {
            c++;
            cur = cur.next;
        }
        return c;
    }
}