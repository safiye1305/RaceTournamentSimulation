public class CarSLL {
    CarNode head;

    public CarSLL() {
        head = null;
    }

    // Büyükten küçüğe sıralar (en yüksek performans skoru üstte)
    public void insertSorted(Car car) {
        CarNode newNode = new CarNode(car);
        if (head == null || head.car.performanceScore < car.performanceScore) {
            newNode.next = head;
            head = newNode;
            return;
        }
        CarNode current = head;
        while (current.next != null && current.next.car.performanceScore >= car.performanceScore) {
            current = current.next;
        }
        newNode.next = current.next;
        current.next = newNode;
    }

    public Car findById(int id) {
        CarNode current = head;
        while (current != null) {
            if (current.car.id == id) return current.car;
            current = current.next;
        }
        return null;
    }

    public void removeById(int id) {
        if (head == null) return;
        if (head.car.id == id) {
            head = head.next;
            return;
        }
        CarNode current = head;
        while (current.next != null) {
            if (current.next.car.id == id) {
                current.next = current.next.next;
                return;
            }
            current = current.next;
        }
    }

    public void display() {
        System.out.println("  +-----+--------------+-------+----------+");
        System.out.println("  | ID  | NAME         | SCORE | TYPE     |");
        System.out.println("  +-----+--------------+-------+----------+");
        CarNode current = head;
        while (current != null) {
            System.out.printf("  | %-3d | %-12s | %-5d | %-8s |\n",
                    current.car.id, current.car.name,
                    current.car.performanceScore, current.car.type);
            current = current.next;
        }
        System.out.println("  +-----+--------------+-------+----------+");
    }

    public int count() {
        int count = 0;
        CarNode current = head;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }

    public Car getAtIndex(int index) {
        CarNode current = head;
        int i = 0;
        while (current != null) {
            if (i == index) return current.car;
            i++;
            current = current.next;
        }
        return null;
    }
}