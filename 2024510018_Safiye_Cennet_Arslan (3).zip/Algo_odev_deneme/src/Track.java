public class Track {
    int id;
    String name;
    String type;
    int difficulty;
    int boost;

    public Track(int id, String name, String type, int difficulty, int boost) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.difficulty = difficulty;
        this.boost = boost;
    }
}