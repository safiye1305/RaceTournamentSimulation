public class RaceLogNode {
    RaceLogEntry entry;
    RaceLogNode next;

    public RaceLogNode(RaceLogEntry entry) {
        this.entry = entry;
        this.next = null;
    }
}