public class TrackSLL {
    TrackNode head;

    public TrackSLL() {
        head = null;
    }

    public void add(Track track) {
        TrackNode newNode = new TrackNode(track);
        if (head == null) {
            head = newNode;
            return;
        }
        TrackNode current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }

    public Track findById(int id) {
        TrackNode current = head;
        while (current != null) {
            if (current.track.id == id) return current.track;
            current = current.next;
        }
        return null;
    }

    public void removeById(int id) {
        if (head == null) return;
        if (head.track.id == id) {
            head = head.next;
            return;
        }
        TrackNode current = head;
        while (current.next != null) {
            if (current.next.track.id == id) {
                current.next = current.next.next;
                return;
            }
            current = current.next;
        }
    }

    public int count() {
        int count = 0;
        TrackNode current = head;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }

    public Track getAtIndex(int index) {
        TrackNode current = head;
        int i = 0;
        while (current != null) {
            if (i == index) return current.track;
            i++;
            current = current.next;
        }
        return null;
    }

    public void display() {
        System.out.print("  ");
        TrackNode current = head;
        while (current != null) {
            System.out.print(current.track.name);
            if (current.next != null) System.out.print(" -> ");
            current = current.next;
        }
        System.out.println(" -> [END]");
    }
}