public class TrackNode {
    Track track;
    TrackNode next;

    public TrackNode(Track track) {
        this.track = track;
        this.next = null;
    }
}