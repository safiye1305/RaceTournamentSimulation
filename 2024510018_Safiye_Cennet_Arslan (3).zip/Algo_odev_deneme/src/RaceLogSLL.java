public class RaceLogSLL {
    RaceLogNode head;
    RaceLogNode tail;

    public RaceLogSLL() {
        head = null;
        tail = null;
    }

    public void add(RaceLogEntry entry) {
        RaceLogNode node = new RaceLogNode(entry);
        if (head == null) {
            head = node;
            tail = node;
        } else {
            tail.next = node;
            tail = node;
        }
    }

    public void printAll() {
        RaceLogNode current = head;
        int entryNum = 1;
        while (current != null) {
            RaceLogEntry e = current.entry;

            System.out.println("========================================================================");
            System.out.println("[ ENTRY " + entryNum + " ] " + e.raceId);
            System.out.println("        Track: " + e.trackName);
            System.out.println("        Matchup: " + e.car1Name + " vs " + e.car2Name);
            System.out.println("        Winner: " + e.winnerName);
            System.out.println("    |");
            System.out.println("    V");

            String header = "  Step | " + padRight(e.car1Name, 35) + " | " + padRight(e.car2Name, 35);
            System.out.println(header);
            System.out.println("  -----+------------------------------------+------------------------------------");

            int total = e.stepLog.count();
            int firstShown = 3;
            int lastShown = 1;
            int stepIdx = 0;
            boolean skipped = false;

            StepLogNode cur = e.stepLog.head;
            while (cur != null) {
                stepIdx++;
                boolean isFirst = stepIdx <= firstShown;
                boolean isLast = stepIdx >= total - lastShown + 1;

                if (isFirst || isLast) {
                    String stepNum = (cur.stepNumber < 10 ? "0" : "") + cur.stepNumber;
                    String line = "  " + stepNum + "   | " + padRight(cur.car1Line, 35) + " | " + padRight(cur.car2Line, 35);
                    System.out.println(line);
                } else {
                    if (!skipped) {
                        int skipFrom = firstShown + 1;
                        int skipTo = total - lastShown;
                        if (skipFrom <= skipTo) {
                            String skipFrom2 = (skipFrom < 10 ? "0" : "") + skipFrom;
                            String skipTo2 = (skipTo < 10 ? "0" : "") + skipTo;
                            System.out.println("  ...  | [Steps " + skipFrom2 + "-" + skipTo2 + " skipped]                   | ...");
                        }
                        skipped = true;
                    }
                }
                cur = cur.next;
            }

            System.out.println("  --------------------------------------------------------------------------");
            entryNum++;
            current = current.next;
        }
    }

    private String padRight(String text, int length) {
        if (text == null) text = "";
        if (text.length() >= length) return text;
        String result = text;
        for (int i = text.length(); i < length; i++) {
            result = result + " ";
        }
        return result;
    }
}