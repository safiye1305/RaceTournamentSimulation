public class TrackUnit {
    int position;
    String effect;       // "normal", "teleport", "reset"
    int teleportDelta;
    TrackUnit prev;
    TrackUnit next;

    public TrackUnit(int position, String effect, int teleportDelta) {
        this.position = position;
        this.effect = effect;
        this.teleportDelta = teleportDelta;
        this.prev = null;
        this.next = null;
    }
}