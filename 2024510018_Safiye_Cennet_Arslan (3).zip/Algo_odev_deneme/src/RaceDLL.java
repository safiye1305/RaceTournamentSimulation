import java.util.Random;

public class RaceDLL {
    TrackUnit head;
    TrackUnit tail;

    public RaceDLL(Random random) {
        buildSkeleton();
        addTraps(random);
    }

    private void buildSkeleton() {
        for (int i = 1; i <= 50; i++) {
            TrackUnit newNode = new TrackUnit(i, "normal", 0);
            if (head == null) {
                head = newNode;
                tail = newNode;
            } else {
                tail.next = newNode;
                newNode.prev = tail;
                tail = newNode;
            }
        }
    }

    private void addTraps(Random random) {
        int teleportCount = 0;
        while (teleportCount < 10) {
            int pos = 2 + random.nextInt(48);
            TrackUnit target = getUnit(pos);
            if (target.effect.equals("normal")) {
                int delta = (random.nextBoolean() ? 1 : -1) * (1 + random.nextInt(5));
                target.effect = "teleport";
                target.teleportDelta = delta;
                teleportCount++;
            }
        }

        boolean resetAssigned = false;
        while (!resetAssigned) {
            int pos = 2 + random.nextInt(48);
            TrackUnit target = getUnit(pos);
            if (target.effect.equals("normal")) {
                target.effect = "reset";
                resetAssigned = true;
            }
        }
    }

    public TrackUnit getUnit(int position) {
        if (position < 1) return head;
        if (position > 50) return tail;
        TrackUnit current = head;
        for (int i = 1; i < position; i++) {
            current = current.next;
        }
        return current;
    }
}