import java.util.Random;

public class RaceEngine {

    private Random random;

    public RaceEngine(Random random) {
        this.random = random;
    }

    public int getMatchupBonus(String type1, String type2) {
        if (type1.equals("Electric") && type2.equals("Water"))   return 15;
        if (type1.equals("Water")    && type2.equals("Fire"))    return 15;
        if (type1.equals("Fire")     && type2.equals("Earth"))   return 15;
        if (type1.equals("Earth")    && type2.equals("Electric")) return 15;
        if (type1.equals("Air")      && type2.equals("Earth"))   return 10;
        if (type1.equals("Heavy")    && type2.equals("Air"))     return 10;
        return 0;
    }

    public int getAdvantage(String typeA, String typeB) {
        return getMatchupBonus(typeA, typeB);
    }

    public int calcInitialScore(Car car, Track track, Car opponent) {
        int score = car.performanceScore;
        if (car.type.equals(track.type)) {
            score += track.boost;
        }
        score += getMatchupBonus(car.type, opponent.type);
        return score;
    }

    public RaceLogEntry performRace(String raceLabel, Car car1, Car car2, Track track) {
        RaceLogEntry logEntry = new RaceLogEntry(raceLabel, track.name, car1.name, car2.name);
        RaceDLL raceDLL = new RaceDLL(random);

        int score1 = calcInitialScore(car1, track, car2);
        int score2 = calcInitialScore(car2, track, car1);

        System.out.println("\n  [RACE PROGRESS]");
        printLine(78);

        String header = "  | " + padRight("Step", 4) + " | " + padRight(car1.name, 31) + " | " + padRight(car2.name, 31) + " |";
        System.out.println(header);
        printLine(78);

        int pos1 = 1;
        int pos2 = 1;
        boolean car1Finished = false;
        boolean car2Finished = false;
        int steps = 0;
        int car1Steps = 0;
        int car2Steps = 0;

        while (!car1Finished || !car2Finished) {
            steps++;
            String car1Line = "";
            String car2Line = "";

            if (!car1Finished && score1 > 0) {
                int move1 = 1 + random.nextInt(3);
                int newPos1 = pos1 + move1;
                score1 -= move1 * 5;

                if (newPos1 >= 50) {
                    newPos1 = 50;
                    car1Line = "Pos " + padZero(pos1) + " -> " + padZero(newPos1) + " (Finish)";
                    pos1 = newPos1;
                    car1Steps = steps;
                    car1Finished = true;
                } else {
                    TrackUnit unit1 = raceDLL.getUnit(newPos1);
                    if (unit1.effect.equals("teleport")) {
                        int afterTeleport = newPos1 + unit1.teleportDelta;
                        if (afterTeleport < 1) afterTeleport = 1;
                        if (afterTeleport > 50) afterTeleport = 50;
                        score1 -= 5;
                        String deltaStr = (unit1.teleportDelta > 0 ? "+" : "") + unit1.teleportDelta;
                        car1Line = "Pos " + padZero(pos1) + " -> " + padZero(newPos1) + " (Teleport " + deltaStr + ") -> " + padZero(afterTeleport);
                        pos1 = afterTeleport;
                        if (pos1 >= 50) { car1Finished = true; car1Steps = steps; }
                    } else if (unit1.effect.equals("reset")) {
                        score1 -= 5;
                        car1Line = "Pos " + padZero(pos1) + " -> " + padZero(newPos1) + " (Reset Trap) -> 01";
                        pos1 = 1;
                    } else {
                        car1Line = "Pos " + padZero(pos1) + " -> " + padZero(newPos1);
                        pos1 = newPos1;
                    }
                }
            }

            if (!car2Finished && score2 > 0) {
                int move2 = 1 + random.nextInt(3);
                int newPos2 = pos2 + move2;
                score2 -= move2 * 5;

                if (newPos2 >= 50) {
                    newPos2 = 50;
                    car2Line = "Pos " + padZero(pos2) + " -> " + padZero(newPos2) + " (Finish)";
                    pos2 = newPos2;
                    car2Steps = steps;
                    car2Finished = true;
                } else {
                    TrackUnit unit2 = raceDLL.getUnit(newPos2);
                    if (unit2.effect.equals("teleport")) {
                        int afterTeleport = newPos2 + unit2.teleportDelta;
                        if (afterTeleport < 1) afterTeleport = 1;
                        if (afterTeleport > 50) afterTeleport = 50;
                        score2 -= 5;
                        String deltaStr = (unit2.teleportDelta > 0 ? "+" : "") + unit2.teleportDelta;
                        car2Line = "Pos " + padZero(pos2) + " -> " + padZero(newPos2) + " (Teleport " + deltaStr + ") -> " + padZero(afterTeleport);
                        pos2 = afterTeleport;
                        if (pos2 >= 50) { car2Finished = true; car2Steps = steps; }
                    } else if (unit2.effect.equals("reset")) {
                        score2 -= 5;
                        car2Line = "Pos " + padZero(pos2) + " -> " + padZero(newPos2) + " (Reset Trap) -> 01";
                        pos2 = 1;
                    } else {
                        car2Line = "Pos " + padZero(pos2) + " -> " + padZero(newPos2);
                        pos2 = newPos2;
                    }
                }
            }

            if (score1 <= 0 && !car1Finished) { car1Finished = true; car1Steps = steps; car1Line += " [Out of fuel]"; }
            if (score2 <= 0 && !car2Finished) { car2Finished = true; car2Steps = steps; car2Line += " [Out of fuel]"; }

            System.out.println("  | " + padZero(steps) + "   | " + padRight(car1Line, 31) + " | " + padRight(car2Line, 31) + " |");
            logEntry.stepLog.add(steps, car1Line, car2Line);
            if (car1Finished && car2Finished) break;
        }

        printLine(78);

        String winner = car1Steps <= car2Steps ? car1.name : car2.name;
        logEntry.winnerName = winner;
        logEntry.car1FinalScore = score1 < 0 ? 0 : score1;
        logEntry.car2FinalScore = score2 < 0 ? 0 : score2;
        logEntry.car1Steps = car1Steps;
        logEntry.car2Steps = car2Steps;

        int winnerSteps = winner.equals(car1.name) ? car1Steps : car2Steps;
        System.out.println("\n  Result: " + winner + " wins in " + winnerSteps + " steps.");
        System.out.println("  Status: [" + track.id + "] " + track.name + " is no longer available.");

        return logEntry;
    }

    private String padRight(String text, int len) {
        if (text == null) text = "";
        String res = text;
        while (res.length() < len) res = res + " ";
        return res;
    }

    private String padZero(int val) {
        if (val < 10) return "0" + val;
        return "" + val;
    }

    private void printLine(int count) {
        System.out.print("  ");
        for (int i = 0; i < count; i++) System.out.print("-");
        System.out.println();
    }
}