import java.io.*;
import java.util.*;

public class Main {
    static CarSLL carList = new CarSLL();
    static TrackSLL trackList = new TrackSLL();
    static RaceLogSLL raceLog = new RaceLogSLL();
    static Random random = new Random();
    static RaceEngine engine = new RaceEngine(random);
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        printLine('=', 70);
        System.out.println("                      RACE TOURNAMENT SIMULATOR");
        printLine('=', 70);

        Car winner1a = null;
        Car winner1b = null;

        loadCars("cars.txt");
        loadTracks("tracks.txt");

        if (carList.count() < 4 || trackList.count() < 2) {
            System.out.println("Hata: Yetersiz veri! En az 4 araba ve 2 pist gerekli.");
            return;
        }
        System.out.println("\n[2] REGISTERED CARS (Ranked by Performance Score)");
        carList.display();

        System.out.println("\n[3] CURRENT TRACK LIST");
        trackList.display();

        System.out.println(" ");
        printLine('-', 70);
        System.out.print(" Race 1a: Player vs Computer ");
        printLine('-', 38);

        Track track1a = playerSelectTrack();
        trackList.removeById(track1a.id);

        Car playerCar = playerSelectCar();
        carList.removeById(playerCar.id);

        Car computerCar1 = computerSelectOpponent(playerCar, track1a);
        if (computerCar1 != null) {
            carList.removeById(computerCar1.id);
            RaceLogEntry entry1a = engine.performRace("Race 1a", playerCar, computerCar1, track1a);
            raceLog.add(entry1a);
            winner1a = entry1a.winnerName.equals(playerCar.name) ? playerCar : computerCar1;
        }

        System.out.println(" ");
        printLine('-', 70);
        System.out.print(" Race 1b: Computer vs Computer ");
        printLine('-', 36);

        Track track1b = pickRandomTrack();
        if (track1b != null) {
            trackList.removeById(track1b.id);
            Car compCar2 = carList.getAtIndex(random.nextInt(carList.count()));
            carList.removeById(compCar2.id);
            Car compCar3 = carList.getAtIndex(random.nextInt(carList.count()));
            carList.removeById(compCar3.id);

            RaceLogEntry entry1b = engine.performRace("Race 1b", compCar2, compCar3, track1b);
            raceLog.add(entry1b);
            winner1b = entry1b.winnerName.equals(compCar2.name) ? compCar2 : compCar3;
        }

        System.out.println(" ");
        printLine('=', 70);
        System.out.println(" FINAL RACE");
        printLine('=', 70);

        Track finalTrack = (winner1a == playerCar) ? playerSelectTrack() : pickRandomTrack();

        if (finalTrack != null && winner1a != null && winner1b != null) {
            trackList.removeById(finalTrack.id);
            RaceLogEntry entryFinal = engine.performRace("Final Race", winner1a, winner1b, finalTrack);
            raceLog.add(entryFinal);

            System.out.println(" ");
            printLine('=', 70);
            System.out.println(" TOURNAMENT CHAMPION: " + entryFinal.winnerName + "!");
            printLine('=', 70);
        }
        System.out.println("\n");
        printLine('=', 72);
        System.out.println(" RACE LOG");
        printLine('=', 72);
        raceLog.printAll();
    }

    static void loadCars(String fileName) throws Exception {
        File file = new File(fileName);
        if (!file.exists()) file = new File("src/" + fileName);
        if (!file.exists()) {
            System.out.println("Dosya bulunamadı: " + fileName);
            return;
        }
        Scanner scanner = new Scanner(file);
        if (scanner.hasNextLine()) scanner.nextLine(); // header'ı atla
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] p = line.split(",");
            if (p.length >= 4) {
                Scanner scanner2 = new Scanner(p[0].trim());
                Scanner scanner3 = new Scanner(p[2].trim());
                int id   = scanner2.nextInt();
                int year = scanner3.nextInt();
                carList.insertSorted(new Car(id, p[1].trim(), year, p[3].trim()));
                scanner2.close();
                scanner3.close();
            }
        }

        scanner.close();
    }
    static void loadTracks(String fileName) throws Exception {
        File file = new File(fileName);
        if (!file.exists()) file = new File("src/" + fileName);
        if (!file.exists()) {
            System.out.println("Dosya bulunamadı: " + fileName);
            return;
        }
        Scanner scanner = new Scanner(file);
        if (scanner.hasNextLine()) scanner.nextLine(); // header'ı atla
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] p = line.split(",");
            if (p.length >= 5) {
                Scanner s1 = new Scanner(p[0].trim());
                Scanner s2 = new Scanner(p[3].trim());
                Scanner s3 = new Scanner(p[4].trim());
                int id       = s1.nextInt();
                int field4   = s2.nextInt();
                int field5   = s3.nextInt();
                trackList.add(new Track(id, p[1].trim(), p[2].trim(), field4, field5));
                s1.close();
                s2.close();
                s3.close();
            }
        }
        scanner.close();
    }
    static Track playerSelectTrack() {
        System.out.println("\n  Available Tracks:");
        TrackNode cur = trackList.head;
        while (cur != null) {
            System.out.println("    [" + cur.track.id + "] " + cur.track.name);
            cur = cur.next;
        }
        System.out.print("  Enter Track ID: ");
        while (true) {
            String input = scanner.nextLine().trim();
            if (isNumeric(input)) {
                Track t = trackList.findById(Integer.parseInt(input));
                if (t != null) return t;
            }
            System.out.print("  Invalid ID. Enter Track ID: ");
        }
    }
    static Car playerSelectCar() {
        System.out.println("\n  Available Cars:");
        CarNode cur = carList.head;
        while (cur != null) {
            System.out.println("    [" + cur.car.id + "] " + cur.car.name);
            cur = cur.next;
        }
        System.out.print("  Enter Car ID: ");
        while (true) {
            String input = scanner.nextLine().trim();
            if (isNumeric(input)) {
                Scanner s = new Scanner(input);
                int id = s.nextInt();
                s.close();
                Car c = carList.findById(id);
                if (c != null) return c;
            }
            System.out.print("  Invalid ID. Enter Car ID: ");
        }
    }
    static boolean isNumeric(String s) { return s != null && s.matches("\\d+"); }

    static Car computerSelectOpponent(Car pCar, Track t) {
        Car best = null; int bScore = -1;
        CarNode cur = carList.head;
        while (cur != null) {
            int s = cur.car.performanceScore;
            if (cur.car.type.equals(t.type)) s += t.boost;
            s += engine.getMatchupBonus(cur.car.type, pCar.type);
            if (s > bScore) { bScore = s; best = cur.car; }
            cur = cur.next;
        }
        return best;
    }
    static Track pickRandomTrack() {
        int c = trackList.count();
        return (c == 0) ? null : trackList.getAtIndex(random.nextInt(c));
    }
    static void printLine(char c, int count) {
        for (int i = 0; i < count; i++) System.out.print(c);
        System.out.println();
    }
}