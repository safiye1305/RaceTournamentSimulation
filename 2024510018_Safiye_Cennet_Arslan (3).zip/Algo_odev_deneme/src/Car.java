public class Car {
    int id;
    String name;
    int performanceScore;
    String type;
    boolean active;

    public Car(int id, String name, int performanceScore, String type) {
        this.id = id;
        this.name = name;
        this.performanceScore = performanceScore;
        this.type = type;
        this.active = true;
    }
}