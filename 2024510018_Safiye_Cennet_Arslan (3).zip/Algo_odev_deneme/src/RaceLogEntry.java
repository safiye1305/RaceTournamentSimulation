public class RaceLogEntry {
    String raceId;
    String trackName;
    String car1Name;
    String car2Name;
    String winnerName;
    int car1FinalScore;
    int car2FinalScore;
    int car1Steps;
    int car2Steps;
    StepLogSLL stepLog;

    public RaceLogEntry(String raceId, String trackName, String car1Name, String car2Name) {
        this.raceId = raceId;
        this.trackName = trackName;
        this.car1Name = car1Name;
        this.car2Name = car2Name;
        this.stepLog = new StepLogSLL();
    }
}